/**
 *  Generic class for loading HTML content of Web page and Generate images.
 */
package com.sitegraph.core;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.apache.log4j.Logger;

import com.sitegraph.core.attributes.ImageAttributes;
import com.sitegraph.core.attributes.JPEGImageAttributes;
import com.sitegraph.core.attributes.PNGImageAttributes;
import com.sitegraph.core.util.Constants;
import com.trolltech.qt.core.QObject;
import com.trolltech.qt.core.QSize;
import com.trolltech.qt.core.QUrl;
import com.trolltech.qt.core.Qt.AspectRatioMode;
import com.trolltech.qt.core.Qt.Orientation;
import com.trolltech.qt.core.Qt.ScrollBarPolicy;
import com.trolltech.qt.core.Qt.TransformationMode;
import com.trolltech.qt.gui.QApplication;
import com.trolltech.qt.gui.QColor;
import com.trolltech.qt.gui.QImage;
import com.trolltech.qt.gui.QPainter;
import com.trolltech.qt.network.QNetworkRequest;
import com.trolltech.qt.webkit.QWebPage;


	public class SiteGraphThumbnailer extends QObject{

	private static final Logger logger = Logger.getLogger(SiteGraphThumbnailer.class);
	/**
	 * @param args
	 */
	protected QWebPage page;
	protected QUrl url;
	protected List<ImageAttributes> imageAttributes=null;
	public Signal0 finished = new Signal0();
	
	/*
	 * Default constructor forcefully added for aop scoped auto proxy 
	 */
	public SiteGraphThumbnailer(){
		this(null,Constants.DEFAULT_URL,Arrays.asList(new ImageAttributes[]{ new PNGImageAttributes()}));
	}
	/**
	 * @param url URL of Web Page in String
	 */
	public SiteGraphThumbnailer(String url){
		this(null,url,Arrays.asList(new ImageAttributes[]{ new PNGImageAttributes()}));
	}
	
	/**
	 * @param url URL of Web Page in String
	 * @param imageAttributes object of ImageAttribute Class to provide specific image related information
	 */
	public SiteGraphThumbnailer(String url,ImageAttributes imageAttribute){
		this(null,url,Arrays.asList(imageAttribute));
	}
	
	/**
	 * @param url URL of Web Page in String
	 * @param imageAttributes List of ImageAttribute Class to provide specific image related information
	 */
	public SiteGraphThumbnailer(String url,List<ImageAttributes> imageAttributes){
		this(null,url,imageAttributes);
	}
	
	/**
	 * @param object object of QObject class 
	 * @param url URL of Web Page in String
	 * @param imageAttributes object of ImageAttribute Class to provide specific image related information
	 */
	public SiteGraphThumbnailer(QObject obj,String url,List<ImageAttributes> imageAttributes){
		super(obj);
		this.imageAttributes=imageAttributes;
		this.url=new QUrl(url);
	}
	
	/**
	 * @return Returns QUrl Object of Url associated with SiteGraphThumbnailer Class  
	 */
	public QUrl getUrl() {
		return url;
	}
	
	/**
	 * @param QUrl object
	 */
	public void setUrl(QUrl url) {
		this.url = url;
	}
	
	/**
	 * @return Returns QUrl Object of Url associated with SiteGraphThumbnailer Class  
	 */
	public List<ImageAttributes> getImageAttributes() {
		return imageAttributes;
	}
	
	/**
	 * @return Returns QUrl Object of Url associated with SiteGraphThumbnailer Class  
	 */
	public void setImageAttributes(List<ImageAttributes> imageAttributes) {
		this.imageAttributes = imageAttributes;
	}
	
	/**
	 * Method to load html content from provided url   
	 */
	public boolean makeSnap(){
		try{
		if(logger.isDebugEnabled())
			logger.debug("Connecting to url : "+this.url);
		if(QApplication.instance() == null)
			QApplication.initialize(new String[] { });
		page = new QWebPage(null);
		page.mainFrame().load(new QNetworkRequest(this.url));
		logger.debug("Page Loaded");
		page.loadStarted.connect(this, "loadStarted()");
		page.loadProgress.connect(this, "loadProgress()");
		page.loadFinished.connect(this, "loadDone()");
		logger.debug("Load Finished");
		finished.connect(QApplication.instance(), "quit()");
		QApplication.exec();
    	}catch(Exception exp){
			logger.error(exp.getMessage()+ " Error While taking a snap");
			return false;
		}
		return true;
	}
	private void loadStarted(){
		logger.debug("Part in Started");
	}
	private void loadProgress(){
		logger.debug("Part in Progress");
	}
	/**
	 * Called internally by makeSnap() method to save loaded image(s) based on provided ImageAttribute details.  
	 */
	private boolean loadDone() {
		logger.debug("Loading for page url : "+ this.url);
		for(ImageAttributes imageAttribute: this.imageAttributes){
			logger.debug("Loading for page url : "+ this.url);
			page.setViewportSize(imageAttribute.getImageSize());
			page.mainFrame().setScrollBarPolicy(Orientation.Horizontal, ScrollBarPolicy.ScrollBarAlwaysOff);
			page.mainFrame().setScrollBarPolicy(Orientation.Vertical, ScrollBarPolicy.ScrollBarAlwaysOff);
			page.setViewportSize(new QSize(Constants.DEFAULT_IMAGE_WIDTH, Constants.DEFAULT_IMAGE_HEIGHT));
		    QImage image = new QImage(page.viewportSize(), QImage.Format.Format_ARGB32);
		    image.fill(QColor.white.rgb());
		    QPainter painter = new QPainter(image);
		    page.mainFrame().render(painter);
		    painter.end();
		    image = image.scaled(imageAttribute.getImageSize(),AspectRatioMode.IgnoreAspectRatio,TransformationMode.FastTransformation);
		    String imageName= imageAttribute.getAbsoluteImageFilePath() + imageAttribute.getImageSuffix();
		    logger.debug("Preparing image : "+ imageName);
		    logger.info("Image prepared: "+image.save(imageName));
		}
	    finished.emit();
	    return true;
    }
	

	public static void main(String[] args) {
	
		String myWebPage = "http://www.lasthorizon.co.cc";
		  new SiteGraphThumbnailer(myWebPage).makeSnap();
		  new SiteGraphThumbnailer(myWebPage,new PNGImageAttributes()).makeSnap();
		  new SiteGraphThumbnailer(myWebPage,new PNGImageAttributes("C:\\images\\new")).makeSnap();
		  List<ImageAttributes> imageAttributes = new ArrayList<ImageAttributes>();
		  imageAttributes.add(new JPEGImageAttributes("C:\\images\\JPEGImage"));
		  imageAttributes.add(new JPEGImageAttributes(new QSize(800,600),"C:\\images\\JPEGImage_800x600"));
		  imageAttributes.add(new PNGImageAttributes(new QSize(800,600),"C:\\images\\PNGImage_800x600"));
		  new SiteGraphThumbnailer(myWebPage,imageAttributes).makeSnap();
		  
	}

	
}
